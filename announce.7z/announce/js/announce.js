// 轮播图
var play = function (i) {
    for (var loo in loop.childNodes) {
        if (loo % 2) {
            loop.childNodes[loo].style.opacity = "0"
        }
    }
    console.log(i)
    console.log(loop.childNodes[2 * i + 1])
    loop.childNodes[2 * i + 1].style.opacity = "1"
    document.querySelectorAll('#control li').forEach(function (val) {
        val.style.backgroundColor = 'gray'
        val.style.color = 'white'
    })
    document.querySelectorAll('#control li')[i].style.backgroundColor = 'white'
    document.querySelectorAll('#control li')[i].style.color = 'black'
}
var loopNum
if (document.getElementsByClassName("loop-img")[0]) {
    var loop = document.getElementsByClassName("loop-img")[0].childNodes[1].childNodes[1]
    loopNum = 0
    play(loopNum)
    var next = function () {
        loopNum = loopNum < loop.childNodes.length / 2 - 2 ? ++loopNum : 0
        play(loopNum)
    }
    var time = setInterval(next, 5000)

}
if (document.querySelectorAll('#control li')) {
    document.querySelectorAll('#control li').forEach(function (val, ind) {
        val.onclick = function () {
            document.querySelectorAll('#control li').forEach(function (val) {
                val.style.backgroundColor = 'black'
                val.style.color = 'white'
            })
            loopNum = ind
            document.querySelectorAll('#control li')[ind].style.color = 'black'
            document.querySelectorAll('#control li')[ind].style.backgroundColor = 'white'
            console.log(loop.childNodes.length)
            clearInterval(time)
            play(loopNum)
            time = setInterval(next, 5000)
        }
    })
}

//首页类型切换
(function () {
    document.querySelectorAll("#index .title li").forEach(function (value) {
        value.onclick = function () {
            this.parentNode.childNodes.forEach(function (value) {
                value.classList = ""
            })
            this.classList = "active"
            if (this.id == 'new') {
                indexNew()
            }
            else {
                indexDo()
            }
        }
    })
})()

var detailList = function () {
    category()
    var id = window.location.search.split('=')[1]
    detail(id)
    document.getElementById('subCategory').querySelectorAll('li').forEach(function (value) {
        if (value.id) {
            value.onclick = function () {
                this.parentNode.childNodes.forEach(function (value) {
                    value.classList = ""
                })
                this.classList = "active"
                switch (this.id) {
                    case 'all':
                        detail(id)
                        document.getElementById('title').innerHTML = "全部项目"
                        break
                    case 'new':
                        detail(id, 1)
                        document.getElementById('title').innerHTML = "最新项目"
                        break
                    case 'do':
                        detail(id, 2)
                        document.getElementById('title').innerHTML = "正在进行"
                        break
                    case 'end':
                        detail(id, 3)
                        document.getElementById('title').innerHTML = "已完结"
                        break
                    default:
                        break
                }
            }
        }
    })
}

var detail = function (cid, type) {
    if (!type) {
        document.getElementById('item').innerHTML = '   <li><span class="name">项目名称</span><span>发布日期</span> </li>'
        $.ajax({
            url: window.baseUrl + 'Get/get_project_all',
            data: {
                cid: cid
            },
            dataType: 'json',
            success: function (res) {
                res.forEach(function (val) {
                    var li = document.createElement('li')
                    li.innerHTML = '<a href="./project_detail.html?id=' + val.pid + '"><span class="name">' + val.name + '</span><span>' + new Date(val.datetime * 1000).toLocaleDateString() + '</span></a>'
                    document.getElementById('item').appendChild(li)
                })
            }
        })
    }
    else {
        document.getElementById('item').innerHTML = '   <li><span class="name">项目名称</span><span>发布日期</span> </li>'
        $.ajax({
            url: window.baseUrl + 'Get/get_project_type',
            data: {
                cid: cid,
                type: type
            },
            dataType: 'json',
            success: function (res) {
                res.forEach(function (val) {
                    var li = document.createElement('li')
                    li.innerHTML = '<a href="./project_detail.html?id=' + val.pid + '"><span class="name">' + val.name + '</span><span>' + new Date(val.datetime * 1000).toLocaleDateString() + '</span></a>'
                    document.getElementById('item').appendChild(li)
                })
            }
        })
    }
}

var projectDetail = function () {
    category()
    document.getElementById("return").setAttribute("href", document.referrer)
    var id = window.location.search.split('=')[1]
    console.log(id)
    $.ajax({
        url: window.baseUrl + 'Get/get_project_detail',
        data: {
            pid: id
        },
        type: 'get',
        dataType: 'json',
        success: function (res) {
            var data = res[0]
            document.getElementById('cname').innerHTML = data.cname
            document.getElementById('connecter').innerHTML = data.connecter
            document.getElementById('datetime').innerHTML = data.datetime
            document.getElementById('description').innerHTML = data.description
            document.getElementById('dostatus').innerHTML = data.dostatus
            document.getElementById('email').innerHTML = data.email
            document.getElementById('fileaddress').setAttribute('href', data.fileaddress)
            document.getElementById('fileaddress').innerHTML = data.filename
            document.getElementById('money').innerHTML = data.money
            document.getElementById('name').innerHTML = data.name
            document.getElementById('needtime').innerHTML = data.needtime
            document.getElementById('phone').innerHTML = data.phone

        }
    })
}

window.baseUrl = 'http://localhost:1337/119.29.100.225/weilan/index.php/'
var indexNew = function () {
    document.getElementById('item').innerHTML = ''
    $.ajax({
        url: window.baseUrl + 'Get/get_all',
        type: 'get',
        dataType: 'json',
        success: function (res) {
            res.forEach(function (val) {
                    var li = document.createElement('li')
                    li.innerHTML =
                        '<span>'
                        + val.cname + '</span><span>'
                        + val.name + '</span><span>'
                        + val.needtime + '</span><span>'
                        + new Date(val.datetime * 1000).toLocaleDateString() + '</span> <span>'
                        + val.connecter + '</span> <a href = "./project_detail.html?id='
                        + val.pid + '"> 查看详情 </a> '
                    document.getElementById('item').appendChild(li)
                }
            )
        }
    })
}

var index = function () {
    category()
    indexNew()
}
var category = function () {
    document.getElementById('category').innerHTML = '<li style="width: 360px!important;font-size: 25px;"><a href="./index.html">logo</a></li>'
    $.ajax({
        url: window.baseUrl + 'Get/show_category',
        type: 'get',
        dataType: 'json',
        success: function (res) {
            res.forEach(function (val) {
                var li = document.createElement('li')
                li.innerHTML = '<li><a href="./detail_list.html?cid=' + val.cid + '">' + val.cname + '</a></li>'
                document.getElementById('category').appendChild(li)
            })
            document.getElementById('category').querySelectorAll('li a').forEach(function (val) {
                if (val.href == window.location.href) {
                    val.parentNode.classList = 'active'
                }
            })
        }
    })
}
var indexDo = function () {
    document.getElementById('item').innerHTML = ''
    $.ajax({
        url: window.baseUrl + 'Get/get_do',
        type: 'get',
        dataType: 'json',
        success: function (res) {
            res.forEach(function (val) {
                    var li = document.createElement('li')
                    li.innerHTML =
                        '<span>'
                        + val.cname + '</span><span>'
                        + val.name + '</span><span>'
                        + val.needtime + '</span><span>'
                        + new Date(val.datetime * 1000).toLocaleString().split(" ")[0] + '</span> <span>'
                        + val.connecter + '</span> <a href = "./project_detail.html?id='
                        + val.pid + '"> 查看详情 </a> '
                    document.getElementById('item').appendChild(li)
                }
            )
        }
    })
}