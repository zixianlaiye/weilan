./index.html        首页
./img_code.php        生成图片验证码
./check_code.php        验证输入是否正确
./js/jquery.min.js         jQuery库
本文地址：http://hexianghui.net/article/10.html
欢迎转载！转载请注明本文地址，谢谢。