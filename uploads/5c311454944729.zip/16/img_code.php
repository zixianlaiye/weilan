<?php
/*
 * File: img_code.php
 * Action: 生成图片验证码
 * Url: http://hexianghui.net
 * Author: 何湘辉
 * Date: 2016-2-8 22:52
 */
 
session_start();
$code = '';
for($i=0;$i<4;$i++){
    $code .= rand(0,9);    //4位验证码
}
$_SESSION['code'] = $code;
$im = imagecreate(50,15);    //创建画布
$bg = imagecolorallocate($im, 255, 255, 255);    //设置颜色
$te = imagecolorallocate($im, 255, 0, 0);
imagestring($im, 6, 3, 2, $code,$te);
//输出图像
header("Content_type: image/png");
imagejpeg($im);
?>