<?php
/*
 * File: check_code.php
 * Action: 验证输入是否正确
 * Url: http://hexianghui.net
 * Author: 何湘辉
 * Date: 2016-2-8 22:52
 */
 
session_start();
$code_num = trim($_POST['code']);
if($code_num == $_SESSION["code"]){
    echo 'yes';
}else{
    echo 'no';
}

?>